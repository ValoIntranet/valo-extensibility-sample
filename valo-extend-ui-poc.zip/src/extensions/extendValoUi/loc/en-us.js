define([], function() {
  return {
    "Title": "ExtendValoUiApplicationCustomizer"
  }
});