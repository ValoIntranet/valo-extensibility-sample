declare interface IExtendValoUiApplicationCustomizerStrings {
  Title: string;
}

declare module 'ExtendValoUiApplicationCustomizerStrings' {
  const strings: IExtendValoUiApplicationCustomizerStrings;
  export = strings;
}
