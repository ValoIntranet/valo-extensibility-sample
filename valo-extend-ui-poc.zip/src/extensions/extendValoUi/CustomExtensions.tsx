import * as React from 'react';

import { Location, ExtensionService, TriggerService, Trigger } from '@valo/extensibility';
import { Link } from 'office-ui-fabric-react/lib/Link';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { Guid } from '@microsoft/sp-core-library';

export default class CustomExtensions {
  private extensionService: ExtensionService = null;
  private triggerService: TriggerService = null;

  constructor() {
    this.extensionService = ExtensionService.getInstance();
    this.triggerService = TriggerService.getInstance();
  }

  public register() {
    this.extensionService.registerExtension({
      id: Guid.newGuid().toString(),
      location: Location.NavigationLeft,
      element: <div style={{lineHeight: '60px', display: 'inline-block', marginRight: 'auto'}}>👉 <style>{`.valo-site-logo{display:flex}.valo-site-logo__link{margin-right:15px !important}`}</style></div>
    });

    this.extensionService.registerExtension({
      id: Guid.newGuid().toString(),
      location: Location.NavigationRight,
      element: <div style={{lineHeight: '60px', marginLeft: 'auto'}}>👈 <style>{`.valo-language-switcher-container{margin-left:7px}`}</style></div>
    });

    this.extensionService.registerExtension({
      id: Guid.newGuid().toString(),
      location: Location.ToolboxAction,
      element: (
        <Link onClick={() => {
                let hasBeenInvoked = false;
                let listener = this.triggerService.registerTrigger(Trigger.OpenPageCreationPanel, () => {
                  listener = this.triggerService.getListener(Trigger.OpenPageCreationPanel);
                  if (!hasBeenInvoked) {
                    listener.invokeTrigger();
                  }
                });

                if (listener && !hasBeenInvoked) {
                  hasBeenInvoked = true;
                  listener.invokeTrigger();
                }
              }}
              title={"Custom action"}
              className={`valo-toolbox__tool-menu-item`}>
          <span className="valo-toolbox__tool-menu-item__name">Our custom action</span>
          <Icon className={`valo-toolbox__tool-menu-item__icon`} iconName={"HeartFill"} />
        </Link>
      )
    });
  }
}
